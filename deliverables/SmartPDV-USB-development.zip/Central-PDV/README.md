# Smart PDV Control — Windows 10/11 x64

Dois aplicativos independentes na LAN, sem banco de dados nem serviço externo:

- **SmartPDV-Central-Setup.exe**: instala a Central, que abre diretamente o dashboard HTTPS no navegador do computador administrador, sem login ou cadastro de usuários.
- **SmartPDV-Agent-Setup.exe**: instala o Agent real do caixa. Depois do pareamento, executa sem terminal ou janela na frente do operador e pode iniciar automaticamente após o login Windows.

O computador PDV é cadastrado, mesmo sem contas de usuários na Central. O número do caixa, UUID e credencial individual identificam qual PDV acionou F11. A comunicação usa WebSocket TLS direto com pin SHA-256 do certificado; a remoção do login não removeu o pareamento dos Agents.

**Cartão fiscal VRPDV: ainda não funciona no teste relatado pelo usuário com a
atualização atual.** A tentativa de preservar cadência não resolveu esse caso;
a Central 1.0.11 acrescentou recuperação de JSON, sem outro motor de leitura.
Não há USB remoto implementado. Veja o [estado da investigação](docs/leitura-fiscal-pendente.md).

## JSON de pareamento apagado

Na Central 1.0.11, feche a Central e use **Menu Iniciar → Smart PDV Central → Gerar novo pareamento de PDV**. Informe o numero existente. Isso substitui somente a credencial desse caixa e exige reconfigurar seu Agent. Veja o [procedimento completo](docs/recuperar-pareamento.md). Não apague `central.json` nem recadastre os outros PDVs.

## Instalação e primeiro uso

Os builds Windows para testes são publicados em **Releases** do repositório após build e testes bem-sucedidos no GitHub Actions. Use os pacotes compatíveis indicados abaixo e confira `SHA256SUMS.txt` da respectiva publicação. Os instaladores modernos incluem Python e dependências; os computadores de destino não precisam instalar Python ou acessar a internet. O Agent Win7 exige .NET 4.8. Binários ainda sem assinatura Authenticode.

Instaladores atuais para testes, com recuperação de pareamento e cadência do leitor:

- [Central 1.0.11 — Windows 10/11 x64](https://github.com/Guel29/Central-PDV/releases/download/windows-test-19-1/SmartPDV-Central-Setup.exe).
- [Agent 0.1.7 — Windows 7 SP1, .NET 4.8](https://github.com/Guel29/Central-PDV/releases/download/windows7-agent-20-1/SmartPDV-Agent-Win7-Setup.exe).
- [Agent 1.0.11 — Windows 10/11 x64](https://github.com/Guel29/Central-PDV/releases/download/windows-test-19-1/SmartPDV-Agent-Setup.exe).

Preserva os intervalos observados de rajadas numéricas curtas. Continua sendo
entrada por `SendInput`, sem USB virtual, sem alteração da VR ou autorização por
senha. **Não é correção comprovada do cartão fiscal no VRPDV.** Consulte o
[procedimento de teste, comportamento e limitações](docs/teste-cadencia-leitor.md).

1. Instale a Central no computador administrador. Em **Configuração inicial**, informe seu IP ou nome LAN estável. Não há usuário ou senha do aplicativo.
2. Pelo menu Iniciar, abra **Smart PDV Central > Confiar no certificado local**. O aplicativo confere o fingerprint e solicita confirmação para adicionar o certificado ao armazenamento de confiança do usuário Windows. Não desative verificações TLS.
3. Abra **Cadastrar PDV** para cada caixa, informando um número único. O arquivo de pareamento é salvo em `%LOCALAPPDATA%\SmartPDV\central\pairing\pdv-N.json`; o caminho físico pode variar com Python Microsoft Store durante uso por código-fonte.
4. Transfira o pareamento ao caixa por mídia segura. Instale o Agent e, na configuração inicial, informe o caminho desse arquivo e confirme endereço da Central e número do PDV. A credencial é protegida com DPAPI para aquele usuário Windows. Exclua as cópias de pareamento depois de importar.
5. Inicie a Central. O dashboard abre diretamente; clique **Ativar alarme sonoro** uma vez. No caixa, execute o Agent; mantenha a inicialização automática selecionada no instalador. O operador continua usando o sistema de vendas normalmente.
6. Na Central, permita TCP 8443 somente na rede privada e sub-rede local. Um administrador Windows pode executar:

   ```powershell
   New-NetFirewallRule -DisplayName 'SmartPDV LAN' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8443 -RemoteAddress LocalSubnet -Profile Private
   ```

O dashboard sem senha aceita controle apenas no próprio computador Central (loopback ou conexão originada do endereço local da máquina). Outros computadores LAN podem conectar seus Agents pareados, mas não recebem uma sessão de controle do dashboard. Quem usa a sessão Windows da Central pode operar os caixas; mantenha o computador administrador sob controle da supervisão.

## Operação

F11 global no caixa envia chamado identificado pelo cadastro. O card pisca verde, toca três bipes e repete a cada dez segundos enquanto houver pedidos online. Clique no card para visualizar/controlar a sessão Windows autorizada. Teste mouse, teclado, rolagem, tela cheia, alternância e encerramento. Atendimento ativo é azul; encerramento devolve o card ao amarelo. Offline é cinza e a conexão é refeita automaticamente. A Central pode reiniciar sem exigir que o operador reconfigure o Agent.

O Agent inicia **após o login Windows**, pois precisa do desktop interativo do operador; não roda sobre a tela de login como serviço. Não há janela de operação sobre o caixa. O processo e o atalho permanecem identificáveis no Gerenciador de Tarefas e na pasta Inicializar. Aplicativos elevados/UAC, sessão bloqueada, desktop seguro, Ctrl+Alt+Del, IME e múltiplos monitores não são contornados. A captura usa o monitor principal. Durante controle remoto, operador e supervisor compartilham mouse/teclado da mesma sessão.

## Dados locais

`central.json` guarda PDVs, rede, alarme, dashboard e retenção. `agent.json` guarda número, UUID, Central, porta, fingerprint, token DPAPI e F11 habilitado/desabilitado. Não há cadastro de usuários do aplicativo; campos legados de supervisores em arquivos antigos são ignorados. JSON é escrito por arquivo temporário, flush/fsync e substituição atômica. Diretórios usam ACL para usuário Windows/SYSTEM; o caminho físico é resolvido antes de chamar icacls para compatibilidade com Python Microsoft Store.

Miniaturas e estado ficam em memória; telas e teclas não são gravadas. JPEG de até 320×180 a cada dois segundos, ou 1280×720 a quatro quadros por segundo no atendimento. Logs JSONL diários guardam apenas PDV, solicitação, identificação de atendimento “Central”, horário e resultado controlado; `retention_days` e `max_bytes` configuram retenção/rotação. Preserve a chave e o certificado da Central para manter o pin dos Agents. Reinicie a Central após cadastrar/remover PDVs por configuração.

## Desenvolvimento e testes

Veja [DEVELOPMENT.md](DEVELOPMENT.md) para testar o laboratório sem instalador e o Agent Windows real por código-fonte. O laboratório identifica claramente telas e entrada simuladas. A comunicação TLS é real; a simulação não valida captura ou F11 físicos.

```sh
python3 -m venv /workspace/smartpdv-venv
/workspace/smartpdv-venv/bin/python -m pip install -r requirements-browser.txt
/workspace/smartpdv-venv/bin/python -m pytest -q
/workspace/smartpdv-venv/bin/python tests/development_browser.py
```

Build local dos instaladores: Windows x64, Python 3.12 e Inno Setup 6; execute `powershell -ExecutionPolicy Bypass -File packaging\build.ps1`. O workflow Windows installers executa build, testes nativos, instalação silenciosa de ambos os pacotes, conferência do subsistema GUI sem console e uma requisição HTTPS funcional ao executável Central instalado antes de publicar.

Antes de produção, valide em dois PCs Windows reais: instalação, certificado, ACL/DPAPI, F11 sem foco, áudio com duas pendências, captura/DPI, mouse/teclado/layout, tela cheia, alternância, desconexão/reconexão, reinício da Central, falta de internet mantendo LAN, inicialização após login e carga com o número real de caixas. Os testes automatizados não substituem esse teste físico.

### Agent para Windows 7

Existe um Agent separado em [legacy-agent](legacy-agent/README.md), destinado a **Windows 7 SP1, 32/64 bits, com .NET Framework 4.8**. A workflow `Windows 7 Agent` gera `SmartPDV-Agent-Win7-Setup.exe`. A Central permanece no Windows 10/11. Leia os requisitos e limites de validacao antes do teste no caixa.

### Atualizacao de teclado Windows

Agent Windows 10/11 x64 1.0.1 e Agent legado 0.1.1 usam SendInput com scan codes para a entrada remota (numeros EAN, Enter, modificadores e navegacao). Encerre o Agent e instale a atualizacao na mesma conta Windows. Cadastro e pareamento permanecem no perfil local. Os testes Windows verificam eventos nativos, liberacao de teclas e ABI de entrada. O VRPDV/LS2208 deve ser validado no equipamento de destino; entrada sintetica nao equivale a um leitor USB fisico. Instaladores modernos exigem Windows 10/11 x64; a versao legada publicada destina-se ao Windows 7 SP1 32/64 bits com .NET 4.8. Windows 8/8.1 e ARM nativo nao foram homologados.

### F11 global na Central (1.0.2)

Com o executavel Central em execucao, F11 restaura e traz a janela SmartCentral para frente a partir de outros aplicativos da mesma sessao Windows. Edge/Chrome abrem o dashboard em janela de aplicativo dedicada, identificavel mesmo com outras abas abertas. Se a janela foi fechada, F11 abre novamente; a Central precisa continuar em execucao. O Agent continua usando F11 para chamados apenas no computador PDV. Na Central, F11 passa a ser o atalho global, substituindo o F11 de tela cheia do navegador. Se outro programa ja reservou F11, a Central informa o conflito; nenhum atalho de outro programa e removido. Nao atua na tela bloqueada ou area segura UAC. Em execucao de testes `--no-browser`, nao registra o atalho global.

### Compatibilidade de entrada e diagnostico (Central/Agent 1.0.3, Agent legado 0.1.2)

Cada tecla passa a ter pressao minima de 20 ms: evita reduzir uma leitura rapida a pulsos quase simultaneos de pressionar/soltar. `keyboard_min_press_ms` no JSON do Agent permite de 0 a 100 ms; ausencia conserva 20 ms. O numero de teclas e o Enter original sao preservados. O intervalo nao muda o dispositivo de origem da entrada e nao garante compatibilidade com Raw Input ou com o VRPDV.

Durante um atendimento, a Central atualizada mostra o resultado retornado pelo Windows: entrada aceita ou bloqueada, com o codigo de erro quando fornecido. **Aceite pelo Windows nao comprova que o VRPDV processou o codigo.** Nenhum EAN, caractere, tecla ou conteudo de tela e registrado nesse diagnostico; somente o ultimo resultado transita em memoria para o supervisor que possui a sessao. A recusa de entrada nao derruba o monitoramento. O F11 global da Central permanece ativo. Validacao no VRPDV/LS2208 precisa ser feita no caixa.

### Entrada remota na Central (1.0.9)

O painel **Autorizações de entrada**, suas caixas de seleção e o botão de salvar foram removidos da interface. Teclado, leitor em modo teclado e mouse continuam pelo atendimento remoto. As configurações existentes em `central.json` são preservadas; teclado e mouse são habilitados por padrão em configurações novas. Se uma opção antiga estiver desativada, o atendimento informa isso. Para alterá-la, encerre a Central, preserve uma cópia do JSON e ajuste `peripherals.keyboard` ou `peripherals.mouse` para `true` antes de iniciar novamente. O Agent continua pareado e autenticado pela LAN. A remoção do painel não corrige, por si, a leitura do cartão fiscal no VRPDV.

O campo EAN, seu botão de envio e a autorização exclusiva de leitor foram removidos a pedido do usuário. A Central também rejeita o antigo comando de envio separado de códigos. A propriedade `scanner` de configurações anteriores é ignorada; o backend mantém somente teclado e mouse na política de entrada. Número do PDV, identidade e pareamento permanecem.

Para usar o controle direto, abra o atendimento e clique no campo desejado dentro da imagem remota. Não existe um campo intermediário de leitura. A tecla Escape, antes consumida pela Central, passa a ser enviada quando a imagem remota tem foco. Use **Encerrar atendimento** para fechar a sessão. O navegador pode reservar Escape para sair da tela cheia.

A Central preserva a identificação das teclas, distinguindo números da fileira superior e do teclado numérico, Enter numérico e modificadores esquerdo/direito. Há também o botão **Windows no PDV**. Esses recursos exigem Agent Windows 10/11 1.0.6 ou Agent legado 0.1.5; esta remoção do campo exige atualizar somente a Central. Confira Num Lock nos dois computadores ao usar o teclado numérico: os estados de trava não são sincronizados automaticamente.

A consulta **Verificar permissões** permanece removida. O indicador de resultado de `SendInput` e a versão em `/health` permanecem disponíveis. **O usuário informou que a leitura continua falhando no VRPDV após a versão 1.0.6; a causa ainda não está comprovada.** Aceite pelo Windows não comprova consumo pelo aplicativo. A remoção do campo e o encaminhamento de Escape não corrigem, por si, essa falha. Atalhos reservados pelo Windows, como Ctrl+Alt+Delete, não são gerados por `SendInput` comum. Veja os [limites de periféricos](docs/peripherals.md).

### Identificar o Agent conectado (Central/Agent 1.0.8; Agent legado 0.1.6)

Os cards e o atendimento mostram a versão informada pelo Agent conectado. Um Agent anterior aparece como **Agent sem versão informada**, pois a versão em execução não pode ser confirmada pelo servidor. A indicação não impede o controle, não consulta permissões Windows e não grava conteúdo digitado. A Central limpa a versão ao desconectar; cadastro e pareamento permanecem. O Agent legado também informa versão 0.1.6.0 nas propriedades do executável Windows.

Ao atualizar no PDV, encerre `SmartPDV-Agent-Win7.exe` pelo Gerenciador de Tarefas, instale na mesma conta Windows e inicie pelo atalho **Iniciar Agent** do Menu Iniciar. Confira **Agent conectado: 0.1.7** na Central. A abertura manual avisa se outra instância estiver rodando; a inicialização automática segue silenciosa. No Windows 10/11, a versão atual de teste é 1.0.11; o Agent legado é 0.1.7.

O teste como administrador não resolveu a leitura do cartão fiscal, e o usuário confirmou que o cartão contém só números. A identificação de versão serve para verificar o executável efetivo antes de continuar a investigação; **esta atualização não confirma a correção da falha no VRPDV e não muda o método de entrada**.

### Diagnóstico do cartão fiscal

A leitura de produtos pela Central foi confirmada como funcional; a falha é na autorização por cartão fiscal. Há uma [ferramenta passiva de comparação e procedimento supervisionado](docs/fiscal-card-diagnostic.md), separada dos aplicativos operacionais. Ela não guarda o código do cartão, não altera a VR nem o método de entrada e não é apresentada como correção comprovada.
