'use strict';
const $ = id => document.getElementById(id);
let opening = null;
let socket, pdvs = [], selected = null, audio, alarmTimer, reconnectTimer, stopped = true;
let alarm = {enabled:true,repeat_seconds:10}, lastPending = false, lastMove = 0;
const cards = new Map();
let peripherals = {keyboard:true,mouse:true};
let knownPending = new Set();
function send(data) { if(socket?.readyState !== WebSocket.OPEN)return false;socket.send(JSON.stringify(data));return true; }
function input(event) {
  if(event.kind==='release')keyboard.cancel();
  else if(!['key','key_sequence'].includes(event.kind))keyboard.flush();
  if(selected === null)return;
  if(['key','key_sequence'].includes(event.kind) && !peripherals.keyboard)return;
  if(['mouse','wheel'].includes(event.kind) && !peripherals.mouse)return;
  send({type:'input',number:selected,event});
}
const keyboard=new TimedNumericKeys(input,()=>peripherals.keyboard && selected!==null &&
  pdvs.some(p=>p.number===selected && p.online && p.active && p.timed_keys));
function updateControls() {
  $('windows-key').disabled=!peripherals.keyboard || selected===null;
  const disabled = [!peripherals.keyboard && 'Teclado desativado na configuração da Central',
    !peripherals.mouse && 'Mouse desativado na configuração da Central'].filter(Boolean);
  $('control-help').textContent=[...disabled,'Clique na imagem para controlar · Esc no PDV; na tela cheia, o navegador pode sair'].join(' · ');
}

function beep() {
  if(!audio || audio.state !== 'running' || !alarm.enabled) return;
  for(let i=0;i<3;i++) {
    const osc=audio.createOscillator(), gain=audio.createGain(), t=audio.currentTime+i*.22;
    osc.frequency.value=1100; osc.type='square'; gain.gain.value=.035;
    osc.connect(gain); gain.connect(audio.destination); osc.start(t); osc.stop(t+.12);
  }
}
function updateAlarm() {
  const current = new Set(pdvs.filter(p=>p.online && p.pending).map(p=>`${p.number}:${p.requested_at}`));
  const pending=current.size>0;
  if(lastPending && [...current].some(id=>!knownPending.has(id)))beep();
  knownPending=current;
  if(pending && !lastPending) { beep(); alarmTimer=setInterval(beep,Math.max(10,alarm.repeat_seconds)*1000); }
  if(!pending) {clearInterval(alarmTimer);alarmTimer=null;}
  lastPending=pending;
}
function agentVersion(p) {
  return p?.agent_version ? `Agent conectado: ${p.agent_version}`
    : 'Agent sem versão informada · não é possível confirmar a atualização no PDV';
}
function render() {
  $('summary').textContent=`${pdvs.filter(p=>p.online).length}/${pdvs.length} PDVs online · ${pdvs.filter(p=>p.pending && p.online).length} solicitações`;
  for(const p of pdvs) {
    if(!cards.has(p.number)) {
      const card=document.createElement('button'), title=document.createElement('h2'), img=document.createElement('img'), info=document.createElement('p');
      img.alt=`Miniatura do PDV ${p.number}`; card.append(title,img,info); card.onclick=()=>openRemote(p.number);
      $('cards').append(card); cards.set(p.number,{card,title,img,info});
    }
    const {card,title,img,info}=cards.get(p.number);
    card.className='card'+(!p.online?' offline':p.pending?' pending':p.active?' active':'');
    title.textContent=`PDV ${String(p.number).padStart(2,'0')}`;
    info.textContent=!p.online?'Desconectado':(p.pending?'LIBERAÇÃO SOLICITADA':p.active?`Atendimento · ${p.supervisor}`:'Online · Disponível')+' · '+agentVersion(p);
    if(p.thumbnail) img.src='data:image/jpeg;base64,'+p.thumbnail; else img.removeAttribute('src');
    card.disabled=!p.online;
  }
  if(selected!==null) {
    const p=pdvs.find(p=>p.number===selected);
    $('agent-version').textContent=agentVersion(p);
    if(!p?.online || (!p.active && !p.pending)) {keyboard.cancel();selected=null;updateControls();$('remote').close();}
    else if(p.thumbnail) $('screen').src='data:image/jpeg;base64,'+p.thumbnail;
  }
  updateAlarm();
}
function openRemote(number) {
  input({kind:'release'});
  if(selected!==null && selected!==number) send({type:'end',number:selected,result:'Alternância de PDV'});
  selected=null;updateControls();
  opening=number; send({type:'start',number});
}
function showRemote(number) {
  selected=number;
  $('remote-title').textContent=`PDV ${number} · Atendimento ativo`;
  $('input-status').textContent='Entrada remota: aguardando teclado';
  updateControls();
  $('switch').replaceChildren(...pdvs.filter(p=>p.online).map(p=>new Option(`PDV ${p.number}`,p.number,false,p.number===number)));
  const p=pdvs.find(p=>p.number===number);
  $('agent-version').textContent=agentVersion(p);
  if(p.thumbnail) $('screen').src='data:image/jpeg;base64,'+p.thumbnail;
  if(!$('remote').open) $('remote').showModal();
  $('screen').focus();renderUSB();
}
function endRemote() {
  input({kind:'release'});
  if(selected!==null) send({type:'end',number:selected,result:'Concluído'});
  selected=null;updateControls();$('remote').close();
  if(document.fullscreenElement)document.exitFullscreen();
}
function connect() {
  clearTimeout(reconnectTimer);
  socket=new WebSocket(`wss://${location.host}/dashboard`);
  socket.onopen=()=>{$('connection').textContent='● Central conectada · TLS';updateControls();};
  socket.onmessage=e=>{
    const data=JSON.parse(e.data);
    if(data.type==='state'){pdvs=data.pdvs;alarm=data.alarm;
      renderUSB(data.usb);
      peripherals=data.peripherals || {keyboard:true,mouse:true};
      if(!peripherals.keyboard)keyboard.cancel();
      updateControls();
      $('cards').style.setProperty('--columns',Math.max(1,Math.min(8,data.dashboard.columns||4)));render();}
    else if(data.type==='opened'){showRemote(data.number);opening=null;}
    else if(data.type==='error'){
      opening=null;
      updateControls();alert(data.message);
    }
    else if(data.type==='input_status' && selected===data.number){
      $('input-status').textContent=data.accepted
        ? 'Windows aceitou a entrada · confirme o resultado no aplicativo'
        : `Windows recusou a entrada remota (código ${data.error_code})`;
    }
    else if(data.type==='frame'){
      const p=pdvs.find(p=>p.number===data.number);if(!p)return;
      p.thumbnail=data.jpeg;const src='data:image/jpeg;base64,'+data.jpeg;
      if(cards.has(p.number))cards.get(p.number).img.src=src;
      if(selected===p.number)$('screen').src=src;
    }
  };
  socket.onclose=async()=>{
    $('connection').textContent='Central desconectada · Reconectando';
    renderUSB({...usbState,status:'desconectado',number:null,error:'Sem conexão com a Central'});
    clearInterval(alarmTimer);keyboard.cancel();lastPending=false;selected=null;updateControls();$('remote').close();
    for(const {card,info} of cards.values()){card.className='card offline';card.disabled=true;info.textContent='Conexão com a Central perdida';}
    if(!stopped){
      try{
        const response=await fetch('/session');
        if(response.status===401){
          stopped=true;$('connection').textContent='Acesso local indisponível';return;
        }
      }catch{ /* A Central pode estar reiniciando. */ }
      if(!stopped)reconnectTimer=setTimeout(connect,3000);
    }
  };
}
$('audio').onclick=async()=>{audio ||= new AudioContext();await audio.resume();$('audio').textContent='Alarme ativado';if(lastPending)beep();};
$('windows-key').onpointerdown=e=>e.preventDefault();
$('windows-key').onclick=()=>{
  input({kind:'release'});
  for(const action of ['down','up'])input({kind:'key',key:'Meta',code:'MetaLeft',action});
  $('screen').focus();renderUSB();
};
$('close').onclick=endRemote;$('remote').addEventListener('cancel',e=>{e.preventDefault();endRemote();});
$('switch').onchange=e=>openRemote(Number(e.target.value));
$('fullscreen').onclick=async()=>{
  try{if(document.fullscreenElement)await document.exitFullscreen();else await $('remote-content').requestFullscreen();}
  catch{$('connection').textContent='Tela cheia indisponível neste navegador';}
};
document.addEventListener('fullscreenchange',()=>{$('fullscreen').textContent=document.fullscreenElement?'Sair da tela cheia':'Tela cheia';});
const screen=$('screen');
function point(e,action){
  const r=screen.getBoundingClientRect(), ratio=(screen.naturalWidth||16)/(screen.naturalHeight||9);
  let width=r.width,height=width/ratio;if(height>r.height){height=r.height;width=height*ratio;}
  const x=(e.clientX-r.left-(r.width-width)/2)/width,y=(e.clientY-r.top-(r.height-height)/2)/height;
  if((x<0||x>1||y<0||y>1)&&action!=='up')return;
  input({kind:'mouse',action,x:Math.max(0,Math.min(1,x)),y:Math.max(0,Math.min(1,y)),button:e.button===2?2:0});
}
screen.onpointermove=e=>{if(performance.now()-lastMove>35){point(e,'move');lastMove=performance.now();}};
screen.onpointerdown=e=>{e.preventDefault();screen.focus();screen.setPointerCapture(e.pointerId);point(e,'down');};
screen.onpointerup=e=>{e.preventDefault();point(e,'up');};screen.oncontextmenu=e=>e.preventDefault();
for(const action of ['down','up'])screen.addEventListener('key'+action,e=>{e.preventDefault();keyboard.key(e,action);});
screen.onblur=()=>input({kind:'release'});
screen.onpointercancel=()=>input({kind:'release'});
window.addEventListener('blur',()=>input({kind:'release'}));
document.addEventListener('visibilitychange',()=>{if(document.hidden)input({kind:'release'});});
screen.addEventListener('wheel',e=>{e.preventDefault();input({kind:'wheel',delta:e.deltaY<0?120:-120});},{passive:false});

// Entrada direta, restrita ao computador Central, com sessão local automática.
async function restoreSession(){
  try{
    const response=await fetch('/session');
    if(!response.ok)throw Error('Abra o dashboard no próprio computador Central.');
    stopped=false;connect();
  }catch(e){$('connection').textContent=e.message;}
}
restoreSession();

// USB has its own data tunnel; these controls never send keyboard events.
let usbState={status:'desconectado',devices:[],selection:null,number:null};
function renderUSB(value) {
  if(value)usbState=value;
  const picker=$('usb-device'), previous=picker.value;
  picker.replaceChildren(...usbState.devices.map(d=>{
    const option=new Option(`${d.description || 'USB'} · ${d.busid} · ${d.instance}${d.shared?' · preparado':''}`,d.instance);
    option.disabled=!d.candidate;
    return option;
  }));
  const desired=usbState.selection?.instance || previous;
  if([...picker.options].some(o=>o.value===desired))picker.value=desired;
  const text=`USB: ${usbState.status}${usbState.number?' · PDV '+usbState.number:''}${usbState.error?' · '+usbState.error:''}`;
  $('usb-status').textContent=text;$('usb-remote-status').textContent=text;
  const target=pdvs.find(p=>p.number===selected);
  $('usb-connect').disabled=!target?.usb_capable || !usbState.selection || usbState.status==='conectando';
  $('usb-disconnect').disabled=!usbState.number;
}
$('usb-refresh').onclick=()=>send({type:'usb',action:'refresh'});
$('usb-select').onclick=()=>{
  const device=usbState.devices.find(d=>d.instance===$('usb-device').value);
  if(!device?.candidate)return;
  if(confirm(`Confirme na etiqueta física que este é o LS2208:\n${device.instance}\nFabricante sozinho não comprova o modelo. Selecionar este leitor?`))
    send({type:'usb',action:'select',instance:device.instance,confirm_ls2208:true});
};
$('usb-connect').onclick=()=>{
  keyboard.cancel();
  if(selected!==null && confirm('O leitor poderá ficar indisponível na Central durante o redirecionamento. Conectar ao PDV '+selected+'?'))
    send({type:'usb',action:'connect',number:selected});
};
$('usb-disconnect').onclick=()=>send({type:'usb',action:'disconnect'});
